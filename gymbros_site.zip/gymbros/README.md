# 💪 GYMBROS

> Bareilly's finest. Six brothers. No days off.

## Setup

### 1. Fork / Clone this repo

```bash
git clone https://github.com/YOUR_USERNAME/gymbros.git
```

### 2. Enable GitHub Pages

1. Go to your repo → **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / **root**
4. Save

Your site will be live at: `https://YOUR_USERNAME.github.io/gymbros/`

### 3. Update your username in the code

Find and replace `YOUR_GITHUB_USERNAME` in:
- `js/upload.js`  
- `pages/tanish.html`
- `pages/harshit.html`
- `pages/kunal.html`
- `pages/atharv.html`
- `pages/ankit.html`
- `pages/nishant.html`

### 4. Upload Photos

1. Go to your live site → **Upload Photos** section
2. Create a GitHub Personal Access Token:
   - GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens
   - Permissions: **Contents → Read & Write**
3. Paste token, select bro name + media type, drop files, hit Upload

## Folder Structure

```
gymbros/
├── index.html          ← Main crew page
├── css/style.css       ← All styles
├── js/upload.js        ← GitHub upload logic
├── pages/
│   ├── tanish.html
│   ├── harshit.html
│   ├── kunal.html
│   ├── atharv.html
│   ├── ankit.html
│   └── nishant.html
├── photos/
│   ├── tanish/         ← Drop photos here
│   ├── harshit/
│   ├── kunal/
│   ├── atharv/
│   ├── ankit/
│   └── nishant/
└── videos/             ← Videos go here (named bro_filename)
```

## Weekly Split

| Day | Split |
|-----|-------|
| Monday | Back + Bicep |
| Tuesday | Chest + Tricep |
| Wednesday | Shoulders |
| Thursday | Back + Bicep |
| Friday | Chest + Tricep |
| Saturday | Legs (+ Abs if you dare 😤) |
| Sunday | REST |

---

*No days off. 🔥*
